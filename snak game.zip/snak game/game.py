import pygame   #for game window
import random   #for random food placement
from enum import Enum #snake direction

BLOCK_SIZE = 20
SPEED = 15
WIDTH = 600
HEIGHT = 400

class Direction(Enum):
    RIGHT = 1
    LEFT = 2
    UP = 3
    DOWN = 4

class SnakeGame:
    def __init__(self, width=WIDTH, height=HEIGHT, render=True):
        self.width = width
        self.height = height
        self.render = render
        self.display = None
        self.clock = None
        if self.render:
            pygame.init()
            self.display = pygame.display.set_mode((self.width, self.height))
            pygame.display.set_caption("Snake - Reinforcement Learning")
            self.clock = pygame.time.Clock()
        self.reset()

    def reset(self):
        self.direction = Direction.RIGHT
        self.head = (self.width // 2, self.height // 2)
        self.snake = [
            self.head,
            (self.head[0] - BLOCK_SIZE, self.head[1]),
            (self.head[0] - 2 * BLOCK_SIZE, self.head[1])
        ]
        self.score = 0
        self.food = None
        self._place_food()
        self.frame_iteration = 0
        return self.get_state()

    def _place_food(self):
        cols = self.width // BLOCK_SIZE
        rows = self.height // BLOCK_SIZE
        while True:
            x = random.randrange(cols) * BLOCK_SIZE
            y = random.randrange(rows) * BLOCK_SIZE
            if (x, y) not in self.snake:
                self.food = (x, y)
                return

    def is_collision(self, point=None):
        if point is None:
            point = self.head
        x, y = point
        if x < 0 or x >= self.width or y < 0 or y >= self.height:
            return True
        if point in self.snake[1:]:
            return True
        return False

    def _move(self, action):
        clockwise = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
        idx = clockwise.index(self.direction)

        # action: 0 = straight, 1 = right, 2 = left
        if action == 1:
            self.direction = clockwise[(idx + 1) % 4]
        elif action == 2:
            self.direction = clockwise[(idx - 1) % 4]

        x, y = self.head
        if self.direction == Direction.RIGHT:
            x += BLOCK_SIZE
        elif self.direction == Direction.LEFT:
            x -= BLOCK_SIZE
        elif self.direction == Direction.DOWN:
            y += BLOCK_SIZE
        elif self.direction == Direction.UP:
            y -= BLOCK_SIZE

        self.head = (x, y)
        self.snake.insert(0, self.head)

    def step(self, action):
        self.frame_iteration += 1
        old_distance = abs(self.head[0] - self.food[0]) + abs(self.head[1] - self.food[1])

        self._move(action)

        if self.is_collision() or self.frame_iteration > 100 * len(self.snake):
            return self.get_state(), -10, True, self.score

        new_distance = abs(self.head[0] - self.food[0]) + abs(self.head[1] - self.food[1])

        if self.head == self.food:
            self.score += 1
            self._place_food()
            self.frame_iteration = 0
            reward = 10
        else:
            self.snake.pop()
            reward = 0.1 if new_distance < old_distance else -0.1

        if self.render:
            self._update_ui()
            self.clock.tick(SPEED)

        return self.get_state(), reward, False, self.score

    def get_state(self):
        # 11 features:
        # danger straight/right/left,
        # current direction 4,
        # food left/right/up/down
        x, y = self.head
        point_straight = self._point_in_direction(self.direction, x, y)
        point_right = self._point_in_direction(self._turn_right(self.direction), x, y)
        point_left = self._point_in_direction(self._turn_left(self.direction), x, y)

        state = [
            int(self.is_collision(point_straight)),
            int(self.is_collision(point_right)),
            int(self.is_collision(point_left)),
            int(self.direction == Direction.LEFT),
            int(self.direction == Direction.RIGHT),
            int(self.direction == Direction.UP),
            int(self.direction == Direction.DOWN),
            int(self.food[0] < x),
            int(self.food[0] > x),
            int(self.food[1] < y),
            int(self.food[1] > y),
        ]
        return state

    @staticmethod
    def _turn_right(direction):
        return {
            Direction.RIGHT: Direction.DOWN,
            Direction.DOWN: Direction.LEFT,
            Direction.LEFT: Direction.UP,
            Direction.UP: Direction.RIGHT,
        }[direction]

    @staticmethod
    def _turn_left(direction):
        return {
            Direction.RIGHT: Direction.UP,
            Direction.UP: Direction.LEFT,
            Direction.LEFT: Direction.DOWN,
            Direction.DOWN: Direction.RIGHT,
        }[direction]

    @staticmethod
    def _point_in_direction(direction, x, y):
        if direction == Direction.RIGHT:
            x += BLOCK_SIZE
        elif direction == Direction.LEFT:
            x -= BLOCK_SIZE
        elif direction == Direction.DOWN:
            y += BLOCK_SIZE
        elif direction == Direction.UP:
            y -= BLOCK_SIZE
        return (x, y)

    def _update_ui(self):
        self.display.fill((25, 25, 25))
        for p in self.snake:
            pygame.draw.rect(
                self.display, (0, 200, 80),
                pygame.Rect(p[0], p[1], BLOCK_SIZE, BLOCK_SIZE)
            )
        pygame.draw.rect(
            self.display, (220, 50, 50),
            pygame.Rect(self.food[0], self.food[1], BLOCK_SIZE, BLOCK_SIZE)
        )
        font = pygame.font.SysFont("arial", 24)
        text = font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.display.blit(text, (10, 10))
        pygame.display.flip()

    def close(self):
        if self.render:
            pygame.quit()


def human_game():
    game = SnakeGame(render=True)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and game.direction != Direction.DOWN:
                    game.direction = Direction.UP
                elif event.key == pygame.K_DOWN and game.direction != Direction.UP:
                    game.direction = Direction.DOWN
                elif event.key == pygame.K_LEFT and game.direction != Direction.RIGHT:
                    game.direction = Direction.LEFT
                elif event.key == pygame.K_RIGHT and game.direction != Direction.LEFT:
                    game.direction = Direction.RIGHT

        _, _, done, _ = game.step(0)
        if done:
            game.reset()
    game.close()

if __name__ == "__main__":
    human_game()

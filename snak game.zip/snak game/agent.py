import random
from collections import deque
import numpy as np
import torch
from model import LinearQNet, QTrainer

MAX_MEMORY = 100_000
BATCH_SIZE = 1000
LR = 0.001
GAMMA = 0.9

class Agent:
    def __init__(self):
        self.n_games = 0    # Number of games played
        self.epsilon = 0    # Exploration rate
        self.memory = deque(maxlen=MAX_MEMORY)
        self.model = LinearQNet(11, 128, 3)
        self.trainer = QTrainer(self.model, LR, GAMMA)

    def get_state(self, game):
        return np.array(game.get_state(), dtype=np.float32)

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def train_long_memory(self):
        if len(self.memory) > BATCH_SIZE:
            mini_sample = random.sample(self.memory, BATCH_SIZE)
        else:
            mini_sample = self.memory

        if not mini_sample:
            return

        states, actions, rewards, next_states, dones = zip(*mini_sample)
        self.trainer.train_step(states, actions, rewards, next_states, dones)

    def train_short_memory(self, state, action, reward, next_state, done):
        self.trainer.train_step(state, action, reward, next_state, done)

    def get_action(self, state):
        # Exploration gradually decreases as training progresses.
        self.epsilon = max(5, 80 - self.n_games)
        final_move = [0, 0, 0]

        if random.randint(0, 200) < self.epsilon:
            move = random.randint(0, 2)
        else:
            state0 = torch.tensor(state, dtype=torch.float)
            prediction = self.model(state0)
            move = torch.argmax(prediction).item()

        final_move[move] = 1
        return final_move

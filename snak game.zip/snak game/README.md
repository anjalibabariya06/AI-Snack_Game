# Snake RL — Deep Q-Learning

A complete Snake game where an AI agent learns to play using Reinforcement Learning (Deep Q-Learning / DQN).

## Run

1. Create/activate a virtual environment (optional but recommended).
2. Install dependencies:
   `pip install -r requirements.txt`
3. Train the AI:
   `python train.py`
4. Watch the trained AI:
   `python play_ai.py`
5. Play manually:
   `python game.py`

The trained model is saved to `models/snake_dqn.pth`.

## RL setup

- State: 11 binary features describing danger, direction, and food location.
- Actions: straight, turn right, turn left.
- Rewards:
  - +10 for eating food
  - -10 for dying
  - +0.1 when moving closer to food
  - -0.1 when moving farther from food
- Algorithm: Deep Q-Network (DQN)
- Experience replay + target network
- Framework: PyTorch

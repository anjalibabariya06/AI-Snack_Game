#py -3.11 play_ai.py
import time
import torch

from game import SnakeGame
from agent import Agent


def play():
    agent = Agent()
    model_path = "models/snake_dqn.pth"

    try:
        agent.model.load(model_path)
    except FileNotFoundError:
        print("Model not found. Run: py -3.11 train.py")
        return

    game = SnakeGame(render=True)
    game.reset()

    while True:
        state = agent.get_state(game)

        # Use trained model directly — no random exploration
        state0 = torch.tensor(state, dtype=torch.float)
        prediction = agent.model(state0)

        move = torch.argmax(prediction).item()

        action = [0, 0, 0]
        action[move] = 1

        _, _, done, score = game.step(action.index(1))

        if done:
            print(f"AI game over. Score: {score}")
            time.sleep(1)
            game.reset()


if __name__ == "__main__":
    play()
import os
import random
import numpy as np
from game import SnakeGame
from agent import Agent

def train():
    agent = Agent()
    game = SnakeGame(render=False)

    scores = []
    total_score = 0
    record = 0

    episodes = 1000

    for episode in range(episodes):
        game.reset()
        state_old = agent.get_state(game)
        done = False

        while not done:
            final_move = agent.get_action(state_old)
            state_new, reward, done, score = game.step(final_move.index(1))

            agent.train_short_memory(
                state_old, final_move, reward, state_new, done
            )
            agent.remember(
                state_old, final_move, reward, state_new, done
            )

            state_old = state_new

        agent.n_games += 1
        agent.train_long_memory()

        if score > record:
            record = score
            agent.model.save()

        scores.append(score)
        total_score += score
        mean_score = total_score / (episode + 1)

        print(
            f"Episode {episode + 1:4d}/{episodes} | "
            f"Score: {score:3d} | Record: {record:3d} | "
            f"Mean: {mean_score:.2f}"
        )

    game.close()

    os.makedirs("results", exist_ok=True)
    np.savetxt("results/scores.csv", np.array(scores), delimiter=",")
    print("\nTraining complete.")
    print("Best model:", os.path.abspath("models/snake_dqn.pth"))
    print("Scores:", os.path.abspath("results/scores.csv"))

if __name__ == "__main__":
    train()
